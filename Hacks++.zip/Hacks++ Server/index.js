const CloudInteract = require('./lib/CloudInteract')

module.exports = CloudInteract

const WebSocketServer = require("ws").WebSocketServer;

const server = new WebSocketServer({port: 8080});

const cloudInteract = new CloudInteract(server);

function sleep(milliseconds) {
    const date = Date.now();
    let currentDate = null;
    do {
      currentDate = Date.now();
    } while (currentDate - date < milliseconds);
  }

cloudInteract.on('connection', (ws) => {
    const UUID = ws.UUID;
    const name = ws.name;
    const inGame = ws.inGame;

    console.log("New connection from: " + name);
    
    if(ws.inGame) {
        ws.execute('RECONNECT', '$${log("Re-connected to CloudInteract")}$$');
    }

    ws.on('joined', () => {
        console.log('The player: ' + name + ' has joined the game!')
        ws.execute('STARTUP', '$${log("Connected to CloudInteract as ' + name + ' with UUID: ' + UUID + '")}$$');
        ws.execute('START', '$${$$<ConnectionProtocol.txt>}$$');
    });

    ws.on('left', () => {
        console.log('The player: ' + name + ' has left the game!');
    });
    
    ws.on('value', (value) => {
        console.log("Recieved value: " + value + " from: " + UUID)
    })

    ws.on('disconnected', () => {
        console.log('Connection lost from player: ' + name);
    });
});

cloudInteract.on('error', (message, stack) => {
    console.error('An error occurred: ' + message);
    console.error(stack);
});