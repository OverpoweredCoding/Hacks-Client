https://github.com/cabaletta/baritone
